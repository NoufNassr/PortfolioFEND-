
let card = document.getElementsByClassName("card");
let cards = [...card];

let openedCards = [];
let matchedCard = document.getElementsByClassName("match");

let cardsContainer = document.querySelector(".deck");
let timer = document.querySelector(".timer");
let second = 0, minute = 0;
let interval;

let moves =0;
let movesCounter = document.querySelector(".moves")

let stars = document.querySelectorAll(".fa-star");

let endGame = document.getElementById("endGame")


//-------------- varaibles -----------------------

for (let card of cards) {

    card.addEventListener("click", action);
    card.addEventListener("click", open);
    card.addEventListener("click",finishing);
}
//-------------- EventListener --------------------

function shuffle(array) {
    let currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}

function shuffllingBoard(){
    endGame.classList.remove("show");

   const shuffled = shuffle(cards);

   for (let i= 0; i < shuffled.length; i++){

      [].forEach.call(shuffled, function(item){
        cardsContainer.appendChild(item);
      });

   }
   openedCards = [];
   
   for (let card of cards){

    card.classList.remove("show", "open", "match", "disabled");
  }
   

   moves = 0;
   movesCounter.innerHTML = moves;
   stars[2].style.visibility = "visible";
   stars[1].style.visibility = "visible";

   timer.innerHTML = "0 mins 0 secs";
   second = 0,minute = 0;
   clearInterval(interval);

}
//------------------shuffling & restart-----------------------


function counter(){
    moves++;
    movesCounter.innerHTML = moves;
    rating();

    if(moves == 1){
        second = 0, minute = 0;
        startTimer();
}
}
//------------ moves Counter ----------------

function rating(){

    if (moves > 10 && moves < 14 ){
        stars[2].style.visibility = "collapse";
    }
    if ( moves > 14 ){
        stars[1].style.visibility = "collapse";

    }

}
//-------------- stars rating ---------------
function startTimer(){
    interval = setInterval(function(){
        timer.innerHTML = minute +"mins " + second + "secs";
        second++;
        if(second == 60){
            second=0;
            minute++;
        }
    },1000);
}
//------------------- timer ----------------------

function action(){
    this.classList.toggle("open");
    this.classList.toggle("show");
    this.classList.toggle("disabled");
 }
//------------- clicks actions --------------

function open() {
    openedCards.push(this);
    if(openedCards.length === 2){
        counter();
        if(openedCards[0].type === openedCards[1].type){
            openedCards[0].classList.add("match", "disabled");
            openedCards[1].classList.add("match", "disabled");
            openedCards = [];

        } else {
            openedCards[0].classList.add("unmatched");
            openedCards[1].classList.add("unmatched");

            setTimeout(function(){
                openedCards[0].classList.remove("show", "open","unmatched");
                openedCards[1].classList.remove("show", "open","unmatched");
                Array.prototype.filter.call(cards, function(card){
                    card.classList.remove('disabled');
                    for(var i = 0; i < matchedCard.length; i++){
                        matchedCard[i].classList.add("disabled");
                    }
                });
                openedCards = [];
            },700);
  
        }
    }
};

//---------- actions when card open -----------------------

function finishing(){
    
    if (matchedCard.length == 16){

        clearInterval(interval);
        
        endGame.classList.add("show");
        document.getElementById("rating").innerHTML = document.querySelector(".stars").innerHTML;
        document.getElementById("finishTime").innerHTML = timer.innerHTML;
        document.getElementById("finalMoves").innerHTML = moves;
       
    };
}
















